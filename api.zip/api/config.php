<?php
// ============================================================
//  DOLCE CANDELE — Configuração da Base de Dados MySQL
//  Edita estes valores com as credenciais do teu cPanel.
// ============================================================

define('DB_HOST',     'localhost');          // normalmente localhost no cPanel
define('DB_NAME',     'SEU_DB_NAME');        // nome da base de dados criada no cPanel
define('DB_USER',     'SEU_DB_USER');        // utilizador MySQL do cPanel
define('DB_PASS',     'SUA_DB_PASSWORD');    // password MySQL do cPanel
define('DB_CHARSET',  'utf8mb4');

// URL do frontend (para CORS) — coloca o teu domínio aqui
define('ALLOWED_ORIGIN', '*'); // ou ex: 'https://dolcecandele.pt'
